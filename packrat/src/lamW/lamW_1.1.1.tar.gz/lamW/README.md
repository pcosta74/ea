**lamW** is an `R` package which calculates the real-valued branches of the [Lambert-W function](https://en.wikipedia.org/wiki/Lambert_W_function).

####Note
 - This project attempts to follow [Semantic Versioning](http://semver.org/)
 - This project attempts to follow the changelog system at [Keep a CHANGELOG](http://keepachangelog.com/)